#include<string.h>
#include<stdio.h>

int hello(char*);