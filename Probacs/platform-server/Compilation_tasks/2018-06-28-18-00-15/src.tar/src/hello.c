#include <stdio.h>

int main(){
	printf("Hello world from VM servers !\n");
	return 0;
}